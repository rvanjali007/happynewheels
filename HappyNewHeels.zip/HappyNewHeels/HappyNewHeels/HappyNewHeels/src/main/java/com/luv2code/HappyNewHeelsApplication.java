package com.luv2code;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappyNewHeelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HappyNewHeelsApplication.class, args);
		System.out.println("Server Started....");
	}

}
